using System;
using MySql.Data.MySqlClient;
using Persistence;

namespace DAL
{
    public class SalesDAL
    {
        MySqlConnection connection = DbHelper.GetConnection();
        public int Login(Sales sales)
        {
            int login = 0;
            
            try
            {
                
                connection.Open();
                MySqlCommand command = connection.CreateCommand();
                    command.CommandText = "select * from sales where user_name='" + 
                    sales.UserName + "' and user_password='" + 
                    MD5Algorithsm.CreateMD5(sales.Password)+"'";
                    // command.CommandText = "select * from sales where user_name=@userName and user_pass=@userPass";
                    // command.Parameters.AddWithValue("@userName", sales.UserName);
                    // command.Parameters.AddWithValue("@userPass", MD5Algorithsm.CreateMD5(sales.Password));
                MySqlDataReader reader = command.ExecuteReader();
                if(reader.Read())
                {
                    login = reader.GetInt32("role");
                }else{
                    login = 0;
                }
            }catch{
                login = -1;
            }
            // Console.WriteLine(login);
            return login;
        }
    }
}
