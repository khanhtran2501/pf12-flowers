﻿using System;

namespace BL
{
    public class Class1
    {
    }
}
