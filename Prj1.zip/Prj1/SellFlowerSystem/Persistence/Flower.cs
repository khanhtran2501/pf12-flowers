using System;

namespace Persistence
{
    public class Flower
    {
        public int FlowerID {set;get;}
        public string FlowerName {set;get;}
        public double FlowerPrice {set;get;}
        public string FlowerDescription {set;get;}
    }
}
