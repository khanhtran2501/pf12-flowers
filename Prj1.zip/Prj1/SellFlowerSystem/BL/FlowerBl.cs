using System;
using System.Collections.Generic;
using Persistence;
using DAL;

namespace BL
{
    public class FlowerBL
    {
        // private ItemDAL idal;
        // public ItemBL()
        // {
        //     idal = new ItemDAL();
        // }
        private FlowerDAL fdal = new FlowerDAL();
        public Flower GetFlowerById(int flowerId)
        {
            fdal.GetFlowerById(flowerId);
            return fdal.GetFlowerById(flowerId);
        }
         public Flower GetFlowerByName(string flowerName)
        {
            fdal.GetFlowerByName(flowerName);
            return fdal.GetFlowerByName(flowerName);
        }
        
    }
}