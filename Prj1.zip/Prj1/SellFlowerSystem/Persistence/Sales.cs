using System;

namespace Persistence
{
    public class Sales

    {
        public int SalesId {set;get;}
        public string SalesName {set;get;}
        public string UserName {set;get;}
        public string Password {set;get;}
        public string Telephone {set;get;}
        public int Role {set;get;}
        public static int SALES_ROLE = 1;
    }
    
}