using System;
using Persistence;
using DAL;

namespace BL
{
    public class SalesBL
    {
        private SalesDAL dal = new SalesDAL();
        public int Login(Sales sales)
        {
            return dal.Login(sales);
        }
    }
}
