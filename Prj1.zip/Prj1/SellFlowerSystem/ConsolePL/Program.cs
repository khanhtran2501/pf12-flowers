﻿using System;
using System.Collections.Generic;
using Persistence;
using BL;
using System.Text;

namespace ConsoleAppPL
{
    class Program
    {
        static void Main(string[] args)
        {   Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("===============================");
            Console.WriteLine("|            LOGIN            |");
            Console.WriteLine("===============================");
            Console.Write("| User Name | ");
            string userName = Console.ReadLine();
            Console.Write("| Password  | ");
            string pass = GetPassword();
            Console.WriteLine();
            Console.WriteLine("===============================");
            //valid username password here
            Sales sales = new Sales(){UserName = userName, Password = pass};
            SalesBL bl = new SalesBL();
            int login = bl.Login(sales);
            if(login <= 0)
            {
                Console.WriteLine("Can't Login");
            }else{
                Console.WriteLine("Welcome to system...");
                MainMenu();
            }
        }

       

        static string GetPassword()
        {
            var pass = string.Empty;
            ConsoleKey key;
            do
            {
                var keyInfo = Console.ReadKey(intercept: true);
                key = keyInfo.Key;

                if (key == ConsoleKey.Backspace && pass.Length > 0)
                {
                    Console.Write("\b \b");
                    pass = pass[0..^1];
                }
                else if (!char.IsControl(keyInfo.KeyChar))
                {
                    Console.Write("*");
                    pass += keyInfo.KeyChar;
                }
            }while (key != ConsoleKey.Enter);
            return pass;
        }

        static void MainMenu()
        {
            short mainChoose = 0, flowerChoose;
            string[] mainMenu = {"Flower Management", "Invoice", "Exit"};
            string[] flowerMenu = {"Search By ID", "Search By Name", "Exit"};
            // int choose = 0;
            FlowerBL fbl = new FlowerBL();
            do
            {
                
                // Console.WriteLine("===============================");
                // Console.WriteLine("|             MENU            |");
                // Console.WriteLine("===============================");
                // Console.WriteLine("|  1.  Flower Management        |");
                // Console.WriteLine("|  2.  Invoice                |");
                mainChoose = Menu("         MENU        ", mainMenu);
                switch(mainChoose)
                {
                    case 1: //Flower Mangament
                    
                        do
                        {
                            // Console.WriteLine("===============================");
                            // Console.WriteLine("|       Flower Management       |");
                            // Console.WriteLine("===============================");
                            // Console.WriteLine("|  1.  Search By ID           |");
                            // Console.WriteLine("|  2.  Search By Name     |");
                            flowerChoose = Menu("Flower Management", flowerMenu);
                            Flower f = null;
                            switch(flowerChoose)
                            {
                                case 1: //SearchByID
                                    Console.WriteLine("===============================");
                                    Console.WriteLine("|         Search By ID        |");
                                    Console.WriteLine("===============================");
                                    Console.Write("| Input Flower Id: ");
                                    int flowerId;
                                    if (Int32.TryParse(Console.ReadLine(), out flowerId))
                                    {
                                        f = fbl.GetFlowerById(flowerId);
                                        if(f != null)
                                        {
                                            Console.WriteLine("Flower Name: " + f.FlowerName);
                                            Console.WriteLine("Flower Price: " + f.FlowerPrice);
                                            // Console.WriteLine("Flower Description: " + f.FlowerDescription);                          
                                        }
                                        else
                                        {
                                            Console.WriteLine("No flower with id " + flowerId);
                                        }
                                        System.Console.WriteLine("continue....");
                                        Console.ReadKey();
                                    }
                                    else
                                    {
                                        Console.WriteLine("ID must be a number!");
                                        System.Console.WriteLine("continue....");
                                        Console.ReadKey();
                                    }
                                    break;
                                case 2: //SearchByName
                                    Console.WriteLine("===============================");
                                    Console.WriteLine("|         Search By Name        |");
                                    Console.WriteLine("===============================");
                                    Console.Write("| Input Flower Name: ");
                                    string flowerName = Console.ReadLine();
                                    f = fbl.GetFlowerByName(flowerName);
                                    if(f != null)
                                    {Console.WriteLine("Flower Id: " + f.FlowerID);
                                        Console.WriteLine("Flower Name: " + f.FlowerName);
                                        Console.WriteLine("Flower Price: " + f.FlowerPrice);
                                        // Console.WriteLine("Flower Description: " + f.FlowerDescription);                          
                                    }
                                    else
                                    {
                                        Console.WriteLine("No flower with name " + flowerName);
                                    }
                                    System.Console.WriteLine("continue....");
                                    Console.ReadKey();
                                    break;
                                case 3: //Exit
                                    break;
                                default:
                                    Console.WriteLine("Wrong choose...");

                                    break;
                            }
                        }while (flowerChoose != flowerMenu.Length);
                        break;
                    case 2: //Invoice
                        break;
                    case 3: //Exit3
                        break;
                }
            } while (mainChoose != mainMenu.Length);
        }

        private static short Menu(string title, string[] menuFlowers)
        {
            short choose = 0;
            string line = "========================================";
            Console.WriteLine(line);
            Console.WriteLine(" " + title);
            Console.WriteLine(line);
            for (int i = 0; i < menuFlowers.Length; i++)
            {
                Console.WriteLine(" " + (i + 1) + ". " + menuFlowers[i]);
            }
            Console.WriteLine(line);
            do
            {
                Console.Write("Your choice: ");
                try
                {
                    choose = Int16.Parse(Console.ReadLine());
                    Console.WriteLine("Your choose is not exist.Retype!!! ");
                }
                catch
                {
                    Console.WriteLine("Your Choose is wrong!");
                    continue;
                }
                
            } while (choose <= 0 || choose > menuFlowers.Length);
          
            return choose;
            
        }
    }
}
