using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using Persistence;

namespace DAL
{
    public class FlowerDAL
    {
        MySqlConnection connection = DbHelper.GetConnection();

        public Flower GetFlowerById(int flowerId)
        {
            Flower flower = null;
            try
            {
                connection.Open();
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "select * from flowers where Flowers_Id=@flowerId";
                command.Parameters.AddWithValue("@flowerId", flowerId);
                MySqlDataReader reader = command.ExecuteReader();
                
                if (reader.Read())
                {
                    flower = GetFlower(reader);
                }
                
                return flower;
            }catch{
                
            }
            finally{
                connection.Close();
            }
            return flower;
            // connection.Close();
        }
         public Flower GetFlowerByName(string flowerName)
        {
            Flower flower = null;
            try
            {
                connection.Open();
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "select * from flowers where Flowers_Name like @flowerName";
                command.Parameters.AddWithValue("@flowerName", "%" +flowerName+"%");
                MySqlDataReader reader = command.ExecuteReader();
                
                if (reader.Read())
                {
                    flower = GetFlower(reader);
                }
                
                return flower;
            }catch{
                
            }
            finally{
                connection.Close();
            }
            return flower;
            // connection.Close();
        }
        
        private Flower GetFlower(MySqlDataReader reader)
        {
            Flower flower = new Flower();
            flower.FlowerID = reader.GetInt32("Flowers_Id");
            flower.FlowerName = reader.GetString("Flowers_Name");
            flower.FlowerPrice = reader.GetDouble("Flowers_Price");
        //    flower.FlowerDescription = reader.GetString("Flowers_Description");
            return flower;
        }
    }
}